﻿using Microsoft.AspNetCore.Mvc;

namespace Health_Advice_Group.Controllers
{
    public class WeatherController : Controller
    {
        public IActionResult WeatherForecast()
        {
            return View();
        }

        public IActionResult AirDashboard()
        {
            return View();
        }
    }
}
