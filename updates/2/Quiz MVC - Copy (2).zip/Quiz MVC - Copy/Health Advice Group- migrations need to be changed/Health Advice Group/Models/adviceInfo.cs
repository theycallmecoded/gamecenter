﻿using System.ComponentModel.DataAnnotations;

namespace Health_Advice_Group.Models
{
    public class advice_info
    {
        [Key]
        public string hometext1 { get; set; }
        public string hometext2 { get; set; }
        public string hometext3 { get; set; }
        public string hometext4 { get; set; }
        public string hometext5 { get; set; }
        public string weathertext1 { get; set;}
        public string weathertext2 { get;set; }
        public string weathertext3 { get; set; }
        public string weathertext4 { get; set; }
        public string weathertext5 { get; set; }
        public string airtext1 { get; set; }
        public string airtext2 { get; set; }
        public string airtext3 { get; set; }
        public string airtext4 { get; set; }
        public string airtext5 { get; set; }
        public string extremetext1 { get; set; }
        public string extremetext2 { get; set; }
        public string extremetext3 { get; set; }
        public string extremetext4 { get; set; }
        public string extremetext5 { get; set; }
        public string extreme1text1 { get; set; }
        public string extreme1text2 { get; set; }
        public string extreme1text3 { get; set; }
        public string extreme1text4 { get; set; }
        public string extreme1text5 { get; set; }
        public string extreme2text1 { get; set; }
        public string extreme2text2 { get; set; }
        public string extreme2text3 { get; set; }
        public string extreme2text4 { get; set; }
        public string extreme2text5 { get; set; }
        public string extreme3text1 { get; set; }
        public string extreme3text2 { get; set; }
        public string extreme3text3 { get; set; }
        public string extreme3text4 { get; set; }
        public string extreme3text5 { get; set; }
        


    }
}
