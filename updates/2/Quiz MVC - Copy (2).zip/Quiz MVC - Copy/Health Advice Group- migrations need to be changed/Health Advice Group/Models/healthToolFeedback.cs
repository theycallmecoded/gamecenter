﻿using System.ComponentModel.DataAnnotations;
namespace Health_Advice_Group.Models
{
    public class Class
    {
        [Key]
        public int id { get; set; }
        public string diabetes { get; set; }
        public string bmi { get; set; }
        public string asthma { get; set; }
    }
}
