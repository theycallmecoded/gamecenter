﻿using Microsoft.AspNetCore.Mvc;

namespace Health_Advice_Group.Controllers
{
    public class AdviceAndInfo : Controller
    {
        public IActionResult HealthMatters()
        {
            return View();
        }

        public IActionResult HealthConditions() 
        {
            return View();
        }

        public IActionResult ExtremeWeather() 
        {
            return View();
        }
    }
}
