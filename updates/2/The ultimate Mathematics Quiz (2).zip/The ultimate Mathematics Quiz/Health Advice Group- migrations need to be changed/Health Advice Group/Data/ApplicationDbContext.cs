﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Health_Advice_Group.Models;

namespace Health_Advice_Group.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<User> Users { get; set; }
        //public DbSet<healthToolFeedback> healthToolFeedback_tbl { get; set; }
        //public DbSet<adviceInfo> adviceInfo_tbl {get; set;}
    }
}