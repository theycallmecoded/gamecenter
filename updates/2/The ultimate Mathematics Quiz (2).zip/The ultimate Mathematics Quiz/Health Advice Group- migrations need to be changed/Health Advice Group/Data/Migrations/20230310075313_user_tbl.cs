﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Health_Advice_Group.Data.Migrations
{
    public partial class user_tbl : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "user_tbl",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SecurityQuestion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SecurityAnswer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsAdmin = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_user_tbl", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "health-tool-feedback_tbl",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    diabetes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    bmi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    asthma = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_health-tool-feedback_tbl", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "advice-info_tbl",
                columns: table => new
                {
                    pageid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    hometext1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    hometext2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    hometext3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    hometext4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    hometext5 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    
                    weathertext1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    weathertext2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    weathertext3= table.Column<string>(type: "nvarchar(max)", nullable: false),
                    weathertext4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    weathertext5 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    
                    airtext1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    airtext2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    airtext3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    airtext4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    airtext5 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    
                    extremetext1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extremetext2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extremetext3= table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extremetext4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extremetext5 = table.Column<string>(type: "nvarchar(max)", nullable: false),

                    extreme1text1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme1text2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme1text3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme1text4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme1text5 = table.Column<string>(type: "nvarchar(max)", nullable: false),

                    extreme2text1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme2text2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme2text3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme2text4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme2text5 = table.Column<string>(type: "nvarchar(max)", nullable: false),

                    extreme3text1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme3text2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme3text3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme3text4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    extreme3text5 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_advice-info_tbl", x => x.pageid);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
