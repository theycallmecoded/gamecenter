﻿using Microsoft.AspNetCore.Mvc;

namespace HealthAdviceGroup.Controllers
{
    public class WeatherController : Controller
    {
        public IActionResult WeatherForecast()
        {
            return View();
        }

        public IActionResult AirDashboard()
        {
            return View();
        }
    }
}
