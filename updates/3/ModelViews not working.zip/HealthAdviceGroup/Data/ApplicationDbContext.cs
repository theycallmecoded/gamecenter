﻿using Microsoft.EntityFrameworkCore;
using HealthAdviceGroup.Models;

namespace Health_Advice_Group.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }
    public DbSet<User> Users { get; set; }
    public DbSet<adviceInfo> advice_info { get; set; }
    public DbSet<HealthToolFeedback> healthToolFeedbacks { get; set; }

}