﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HealthAdviceGroup.Migrations
{
    /// <inheritdoc />
    public partial class HealthAdviceGroup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "advice_info",
                columns: table => new
                {
                    pageid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    hometext1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    hometext2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    hometext3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    hometext4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    hometext5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    weathertext1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    weathertext2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    weathertext3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    weathertext4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    weathertext5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    airtext1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    airtext2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    airtext3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    airtext4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    airtext5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extremetext1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extremetext2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extremetext3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extremetext4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extremetext5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme1text1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme1text2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme1text3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme1text4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme1text5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme2text1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme2text2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme2text3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme2text4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme2text5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme3text1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme3text2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme3text3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme3text4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    extreme3text5 = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_advice_info", x => x.pageid);
                });

            migrationBuilder.CreateTable(
                name: "healthToolFeedbacks",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    diabetes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    bmi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    asthma = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_healthToolFeedbacks", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SecurityQuestion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SecurityAnswer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsAdmin = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "advice_info");

            migrationBuilder.DropTable(
                name: "healthToolFeedbacks");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
