﻿using System.ComponentModel.DataAnnotations;

namespace HealthAdviceGroup.Models
{
    public class adviceInfo
    {
        [Key]
        public int pageid { get; set; }
        //All the fields below are set to null so there is no need to have the whole database filled.
        public string hometext1 { get; set; } = null!;
        public string hometext2 { get; set; } = null!;
        public string hometext3 { get; set; } = null!;
        public string hometext4 { get; set; } = null!;
        public string hometext5 { get; set; } = null!;
        public string weathertext1 { get; set; } = null!;
        public string weathertext2 { get; set; } = null!;
        public string weathertext3 { get; set; } = null!;
        public string weathertext4 { get; set; } = null!;
        public string weathertext5 { get; set; } = null!;
        public string airtext1 { get; set; } = null!;
        public string airtext2 { get; set; } = null!;
        public string airtext3 { get; set; } = null!;
        public string airtext4 { get; set; } = null!;
        public string airtext5 { get; set; } = null!;
        public string extremetext1 { get; set; } = null!;
        public string extremetext2 { get; set; } = null!;
        public string extremetext3 { get; set; } = null!;
        public string extremetext4 { get; set; } = null!;
        public string extremetext5 { get; set; } = null!;
        public string extreme1text1 { get; set; } = null!;
        public string extreme1text2 { get; set; } = null!;
        public string extreme1text3 { get; set; } = null!;
        public string extreme1text4 { get; set; } = null!;
        public string extreme1text5 { get; set; } = null!;
        public string extreme2text1 { get; set; } = null!;
        public string extreme2text2 { get; set; } = null!;
        public string extreme2text3 { get; set; } = null!;
        public string extreme2text4 { get; set; } = null!;
        public string extreme2text5 { get; set; } = null!;
        public string extreme3text1 { get; set; } = null!;
        public string extreme3text2 { get; set; } = null!;
        public string extreme3text3 { get; set; } = null!;
        public string extreme3text4 { get; set; } = null!;
        public string extreme3text5 { get; set; } = null!;



    }
}
