﻿using Microsoft.AspNetCore.Mvc;

namespace HealthAdviceGroup.Controllers
{
    public class AdviceAndInfo : Controller
    {
        public IActionResult HealthMatters()
        {
            return View();
        }

        public IActionResult HealthConditions() 
        {
            return View();
        }

        public IActionResult ExtremeWeather() 
        {
            return View();
        }
    }
}
