﻿using System.ComponentModel.DataAnnotations;
namespace HealthAdviceGroup.Models
{
    public class HealthToolFeedback
    {
        [Key]
        public int id { get; set; }
        public string diabetes { get; set; } = null!;
        public string bmi { get; set; } = null!;
        public string asthma { get; set; } = null!;
    }
}